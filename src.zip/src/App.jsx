import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Products from "./pages/Products";
import Inventory from "./pages/Inventory";
import Suppliers from "./pages/Suppliers";
import Sales from "./pages/Sales";
import LowStock from "./pages/LowStock";
import Settings from "./pages/Settings";
import Profile from "./pages/Profile";

function App() {

    const token = localStorage.getItem("token");

    return (

        <BrowserRouter>

            <Routes>

                <Route
                    path="/"
                    element={
                        token
                            ? <Navigate to="/dashboard" replace />
                            : <Login />
                    }
                />

                <Route
path="/register"
element={<Register/>}
/>

                <Route
                    path="/dashboard"
                    element={
                        token
                            ? <Dashboard />
                            : <Navigate to="/" replace />
                    }
                />

                <Route
                    path="/products"
                    element={
                        token
                            ? <Products />
                            : <Navigate to="/" replace />
                    }
                />

                <Route
                    path="/inventory"
                    element={
                        token
                            ? <Inventory />
                            : <Navigate to="/" replace />
                    }
                />

                <Route
                    path="/suppliers"
                    element={
                        token
                            ? <Suppliers />
                            : <Navigate to="/" replace />
                    }
                />

                <Route
                    path="/sales"
                    element={
                        token
                            ? <Sales />
                            : <Navigate to="/" replace />
                    }
                />

                <Route
                    path="/low-stock"
                    element={
                        token
                            ? <LowStock />
                            : <Navigate to="/" replace />
                    }
                />

                <Route
                    path="/settings"
                    element={
                        token
                            ? <Settings />
                            : <Navigate to="/" replace />
                    }
                />

                <Route
                    path="/profile"
                    element={
                        token
                            ? <Profile />
                            : <Navigate to="/" replace />
                    }
                />

                <Route
                    path="*"
                    element={
                        <Navigate
                            to={token ? "/dashboard" : "/"}
                            replace
                        />
                    }
                />

            </Routes>

        </BrowserRouter>

    );

}

export default App;